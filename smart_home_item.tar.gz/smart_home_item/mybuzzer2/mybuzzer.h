#ifndef __MYBUZZER_H__
#define __MYBUZZER_H__

#define beef_on _IOR('a',0,int)
#define beef_off _IOW('a',1,int)

#endif
