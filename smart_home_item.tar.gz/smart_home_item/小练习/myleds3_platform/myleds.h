#ifndef __MYLEDS_H__
#define __MYLEDS_H__

#define LEDS_ON _IOR('a',0,int)
#define LEDS_OFF _IOW('a',0,int)

#endif
